function [doty] = rungeKutta(r, v, G, mC, rC,h)
    % Compute velocity
    r = rC - r;
    r2 = norm(r)^2;
    a = r * G *mC / r2;
    
    % Update velocity
    kv1 = a.*r;
    kr1 = v;
    kv2 = a.*(r+(kr1.*(h./2)));
    kr2 = v.*(kv1.*h./2);
    kv3 = a.*(r+(kr2.*(h./2)));
    kr3 = v.*(kv2.*h./2);
    kv4 = a.*(r+kr3.*h);
    kr4 = v.*(kv3.*h);
    
    doty = zeros(4, 1);
    doty(1:2) = doty(1:2) + (h/6).*(kr1 + 2.*kr2 + 2.*kr3 + kr4);
    doty(3:4) = doty(3:4) + (h/6).*(kv1 + 2.*kv2 + 2.*kv3 + kv4);
end