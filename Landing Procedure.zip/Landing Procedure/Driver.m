close all; clear; clc;
Physics.G = 6.674e-11; % Meters cubed per kg*sec^2
Physics.STEP_SIZE = 1; % Stepsize in seconds
Physics.FINAL_TIME = 8e5; 
Physics.STEP_COUNT = round(Physics.FINAL_TIME/ Physics.STEP_SIZE);
Physics.time = 1; % Elapsed time in seconds

Titan.MASS = 1.3452e23; % Mass in kg
Titan.POSITION = [0;0]; % Position in meters
Titan.RADIUS = 2575e03; % Radius in meters
Titan.ATMOSPHERE_RADIUS = Titan.RADIUS + 200e3;
Titan.PERIOD = 0.1 * 24 * 60 * 60; % Orbital period in sec
Titan.GRAVITY_RADIUS = 122187e04*(Titan.MASS/5.6834e26)^(2/5); % Semimajor axis of Titan times ratio masses of titan and saturn
disp("Sphere of influence");
disp(Titan.GRAVITY_RADIUS);
Rocket.positions = [1.3* Titan.GRAVITY_RADIUS* [-0.7071; 0.7071], zeros(2, Physics.STEP_COUNT)]; % m
disp("Initial position")
disp(Rocket.positions(:,1))
Rocket.velocities = [5e2* [0;-1], zeros(2, Physics.STEP_COUNT)]; % m/s
Rocket.masses = 270000* [1, ones(1, Physics.STEP_COUNT)]; % kg
Rocket.thrusts = zeros(2, Physics.STEP_COUNT +1); % acceleration due to thrust in meters per second
Rocket.orbit.type = 'parabolic';

Lander.positions = [1.3* Titan.GRAVITY_RADIUS* [-0.7071; 0.7071], zeros(2, Physics.STEP_COUNT)]; % m
Lander.velocities = [5e2* [0;-1], zeros(2, Physics.STEP_COUNT)]; % m/s
Lander.masses = 15000* [1, ones(1, Physics.STEP_COUNT)]; % kg
Lander.thrusts = zeros(2, Physics.STEP_COUNT +1); % acceleration due to thrust in meters per second

% Simulate flight
% Phase 1: Simulate the parabolic orbit of rocket and lander up until they 
% fly by titan tangentially. Then adjust the velocity of the rocket to bring
% it into a parking orbit and that of the lander to bring it into the transfer
% orbit.
[Rocket.positions(:, Physics.time+1), Rocket.velocities(:, Physics.time+1)] = eulerSolve(Rocket.positions(:, Physics.time), Rocket.velocities(:, Physics.time), Rocket.thrusts(:, Physics.time), Titan.MASS, Titan.POSITION, Physics.STEP_SIZE);
[Lander.positions(:, Physics.time+1), Lander.velocities(:, Physics.time+1)] = eulerSolve(Lander.positions(:, Physics.time), Lander.velocities(:, Physics.time), Lander.thrusts(:, Physics.time), Titan.MASS, Titan.POSITION, Physics.STEP_SIZE);
Physics.time = Physics.time +1;
[Rocket.positions(:, Physics.time+1), Rocket.velocities(:, Physics.time+1)] = eulerSolve(Rocket.positions(:, Physics.time), Rocket.velocities(:, Physics.time), Rocket.thrusts(:, Physics.time), Titan.MASS, Titan.POSITION, Physics.STEP_SIZE);
[Lander.positions(:, Physics.time+1), Lander.velocities(:, Physics.time+1)] = eulerSolve(Lander.positions(:, Physics.time), Lander.velocities(:, Physics.time), Lander.thrusts(:, Physics.time), Titan.MASS, Titan.POSITION, Physics.STEP_SIZE);
Physics.time = Physics.time +1;
while strcmp(Rocket.orbit.type, 'parabolic')
    [Rocket.positions(:, Physics.time+1), Rocket.velocities(:, Physics.time+1)] = adamsBashforthSolve(Rocket.positions(:, Physics.time-2:Physics.time), Rocket.velocities(:, Physics.time-2:Physics.time), Rocket.thrusts(:, Physics.time-2:Physics.time), Titan.MASS, repmat(Titan.POSITION, [1,3]), Physics.STEP_SIZE);
    [Lander.positions(:, Physics.time+1), Lander.velocities(:, Physics.time+1)] = adamsBashforthSolve(Rocket.positions(:, Physics.time-2:Physics.time), Rocket.velocities(:, Physics.time-2:Physics.time), Rocket.thrusts(:, Physics.time-2:Physics.time), Titan.MASS, repmat(Titan.POSITION, [1,3]), Physics.STEP_SIZE);
    %disp(Rocket.velocities(:, Physics.time+1) - Rocket.velocities(:, Physics.time))
    % Check whether rocket flies by Titan tangentially
    dUnit = (Rocket.positions(:,Physics.time) - Titan.POSITION)/ norm(Rocket.positions(:,Physics.time) - Titan.POSITION);
    vUnit = Rocket.velocities(:,Physics.time)/ norm(Rocket.velocities(:,Physics.time));
    if (vUnit'*dUnit < 0.05) && (vUnit'*dUnit > -0.05)
        % Bring the lander to it's elliptical orbit 
        Lander.isAttached = false;
        muh = Physics.G* (Titan.MASS + Lander.masses(Physics.time)); % https://en.wikipedia.org/wiki/Orbital_mechanics
        Lander.orbit.semimajorAxis = (norm(Lander.positions(:, Physics.time+1) - Titan.POSITION) + Titan.ATMOSPHERE_RADIUS)/2; % Astrobook page 61
        Lander.velocities(:, Physics.time+1) = vUnit * sqrt((-muh/Lander.orbit.semimajorAxis + 2*muh/norm(Lander.positions(:,Physics.time+1)- Titan.POSITION))); % Astrobook page 61 (reformulated formula)
        Lander.orbit.period = round(2*sqrt((Lander.orbit.semimajorAxis^3)/muh)*(pi)); % Astrobook p.37 (reformed)
        % Bring the rocket into a circular orbit
        % velocities(:,Physics.time+1) = vUnit.*sqrt(Physics.G* Titan.MASS/norm(Rocket.positions(:,Physics.time) - Titan.POSITION)); % http://www.softschools.com/formulas/physics/orbital_velocity_formula/76/
        Rocket.orbit.type = 'circular';
        %muh = Physics.G* (Titan.MASS + Rocket.masses(Physics.time +1)); % https://en.wikipedia.org/wiki/Orbital_mechanics
        %C = (Rocket.velocities(:, Physics.time + 1)'* Rocket.velocities(:, Physics.time +1))/ 2 - muh/ norm(Rocket.positions(:,Physics.time + 1)); % Astrobook p. 62
        Rocket.orbit.semimajorAxis = (norm(Lander.positions(:, Physics.time+1) - Titan.POSITION) + Titan.GRAVITY_RADIUS)/2; % Astrobook page 61;-muh/(2*C); % Astrobook p. 62
        Rocket.velocities(:, Physics.time+1) = vUnit * sqrt((-muh/Rocket.orbit.semimajorAxis + 2*muh/norm(Rocket.positions(:,Physics.time+1)- Titan.POSITION))); % Astrobook page 61 (reformulated formula)
        Rocket.orbit.period = round(2*pi*sqrt((Rocket.orbit.semimajorAxis^3)/muh)); % Astrobook p.37 (reformed)
        Rocket.departureTime = Physics.time + Rocket.orbit.period;
        Rocket.departureVelocity = Rocket.velocities(:, Physics.time -1);
    end
    Physics.time = Physics.time +1;
end

% Phase 2: Simulate the orbits of lander and Rocket up until when the lander reaches 
% its apogee.
isAtApogee = false;
while not (isAtApogee) 
    % Check whether the lander flies by Titan tangentially
    dUnit = (Lander.positions(:,Physics.time) - Titan.POSITION)/ norm(Lander.positions(:,Physics.time) - Titan.POSITION);
    vUnit = Lander.velocities(:,Physics.time)/ norm(Lander.velocities(:,Physics.time));
    if not(isAtApogee) && norm(Lander.positions(:,Physics.time) - Titan.POSITION) <= Titan.ATMOSPHERE_RADIUS && (vUnit'*dUnit < 0.05) && (vUnit'*dUnit > -0.05)
        Lander.liftoffVelocity = Lander.velocities(:, Physics.time);
        Lander.liftoffVelocity
        Lander.liftoffPosition = Lander.positions(:, Physics.time);
        isAtApogee = true;
        Lander.positions(:, Physics.time+1: Rocket.departureTime - round(Lander.orbit.period/2)) = repmat(Lander.positions(:, Physics.time), [1, Rocket.departureTime - round(Lander.orbit.period/2)- Physics.time]);
    end
    
    % Solve the differential equations of motion for rocket and lander
    [Rocket.positions(:, Physics.time+1), Rocket.velocities(:, Physics.time+1)] = adamsBashforthSolve(Rocket.positions(:, Physics.time-2:Physics.time), Rocket.velocities(:, Physics.time-2:Physics.time), Rocket.thrusts(:, Physics.time-2:Physics.time), Titan.MASS, repmat(Titan.POSITION, [1,3]), Physics.STEP_SIZE);
    [Lander.positions(:, Physics.time+1), Lander.velocities(:, Physics.time+1)] = adamsBashforthSolve(Lander.positions(:, Physics.time-2:Physics.time), Lander.velocities(:, Physics.time-2:Physics.time), Lander.thrusts(:, Physics.time-2:Physics.time), Titan.MASS, repmat(Titan.POSITION, [1,3]), Physics.STEP_SIZE);
    Physics.time = Physics.time +1;
end

% Phase 3: Simulate the orbit of the rocket until it is time for the lander
% to continue its trajectory.
while Physics.time < (Rocket.departureTime - Lander.orbit.period/2)
    % Solve the differential equations of motion for rocket and lander
    [Rocket.positions(:, Physics.time+1), Rocket.velocities(:, Physics.time+1)] = adamsBashforthSolve(Rocket.positions(:, Physics.time-2:Physics.time), Rocket.velocities(:, Physics.time-2:Physics.time), Rocket.thrusts(:, Physics.time-2:Physics.time), Titan.MASS, repmat(Titan.POSITION, [1,3]), Physics.STEP_SIZE);
    Physics.time = Physics.time +1;
end

% Phase 4: Simlate the orbits of lander and rocket until rendezvous
Lander.positions(:, Physics.time) = Lander.liftoffPosition;
Lander.velocities(:, Physics.time) = Lander.liftoffVelocity;
while Physics.time < (Rocket.departureTime)
    % Solve the differential equations of motion for rocket and lander
    [Rocket.positions(:, Physics.time+1), Rocket.velocities(:, Physics.time+1)] = adamsBashforthSolve(Rocket.positions(:, Physics.time-2:Physics.time), Rocket.velocities(:, Physics.time-2:Physics.time), Rocket.thrusts(:, Physics.time-2:Physics.time), Titan.MASS, repmat(Titan.POSITION, [1,3]), Physics.STEP_SIZE);
    [Lander.positions(:, Physics.time+1), Lander.velocities(:, Physics.time+1)] = adamsBashforthSolve(Lander.positions(:, Physics.time-2:Physics.time), Lander.velocities(:, Physics.time-2:Physics.time), Lander.thrusts(:, Physics.time-2:Physics.time), Titan.MASS, repmat(Titan.POSITION, [1,3]), Physics.STEP_SIZE);
    Physics.time = Physics.time +1;
end

% Phase 5: Attach the lander back to the rocket and simulate their common parabolic orbit. 
Rocket.orbit.type = 'parabolic';
Rocket.velocities(:, Physics.time) = Rocket.departureVelocity;
Lander.positions(:, Physics.time) = Rocket.positions(:, Physics.time);
Lander.velocities(:, Physics.time) = Rocket.velocities(:, Physics.time);
Lander.isAttached = true;
while Physics.time < (Physics.FINAL_TIME)
    % Solve the differential equations of motion for rocket and lander
    [Rocket.positions(:, Physics.time+1), Rocket.velocities(:, Physics.time+1)] = adamsBashforthSolve(Rocket.positions(:, Physics.time-2:Physics.time), Rocket.velocities(:, Physics.time-2:Physics.time), Rocket.thrusts(:, Physics.time-2:Physics.time), Titan.MASS, repmat(Titan.POSITION, [1,3]), Physics.STEP_SIZE);
    [Lander.positions(:, Physics.time+1), Lander.velocities(:, Physics.time+1)] = adamsBashforthSolve(Rocket.positions(:, Physics.time-2:Physics.time), Rocket.velocities(:, Physics.time-2:Physics.time), Rocket.thrusts(:, Physics.time-2:Physics.time), Titan.MASS, repmat(Titan.POSITION, [1,3]), Physics.STEP_SIZE);
    Physics.time = Physics.time +1;
end

% Display simulation
figure; hold on;
diskUniverse = drawDisk(Titan.POSITION(1), Titan.POSITION(2), 9e10, [1,1,1])
diskGravity3 = drawDisk(Titan.POSITION(1),Titan.POSITION(2),1.0* Titan.GRAVITY_RADIUS,[0.9,0.9,0.9]);
diskGravity2 = drawDisk(Titan.POSITION(1),Titan.POSITION(2),0.7* Titan.GRAVITY_RADIUS,[0.8,0.8,0.8]);
diskGravity1 = drawDisk(Titan.POSITION(1),Titan.POSITION(2),0.4* Titan.GRAVITY_RADIUS,[0.7,0.7,0.7]);
diskTitan = drawDisk(Titan.POSITION(1),Titan.POSITION(2),Titan.RADIUS,[0.4,0.4,0.4]); 
xlabel('distance (m)'); ylabel('distance (m)');
Rocket.body = scatter(0,0);
Lander.body = scatter(0,0);
animate = true;
if animate
    pause(1.0);
    for i = 1:1000:Physics.time
        plot(Lander.positions(1,1:i), Lander.positions(2,1:i), 'r');
        delete(Lander.body);
        Lander.body = scatter(Lander.positions(1,i), Lander.positions(2,i),'r');
        xlim([-10e07,10e07]); ylim([-5e07, 5e07]);

        plot(Rocket.positions(1,1:i), Rocket.positions(2,1:i),'b');
        delete(Rocket.body);
        Rocket.body = scatter(Rocket.positions(1,i), Rocket.positions(2,i),'b');
        pause(0.0001)
    end
end
%plot(Rocket.positions(1,1:Physics.time), Rocket.positions(2,1:Physics.time), 'b');
