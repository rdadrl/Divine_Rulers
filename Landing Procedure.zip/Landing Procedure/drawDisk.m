function g = drawDisk(x,y,r,c)
    g = NaN;
    for i = 1:2
        th = (i-1)*pi:pi/50:i*pi;
        xs = r * cos(th) + x;
        ys = r * sin(th) + y;
        g = area(xs, ys);
        g(1).EdgeColor = c;
        g(1).FaceColor = c;
    end
end