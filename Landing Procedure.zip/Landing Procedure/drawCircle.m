function g = drawCircle(x,y,r,c)
    th = 0:pi/50:2*pi;
    xs = r * cos(th) + x;
    ys = r * sin(th) + y;
    g = plot(xs, ys, 'Color', c);
end