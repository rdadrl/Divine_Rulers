% Summary: Solves the differential equation describing the motion of a
% satelite depending on its position, gravity and thrust.
% Parameter pS, vS: 2x3 matrices specyfing the position and velocity 
% due to thrust of the satelite for timepoints t, t-1 and t-2.
% Parameter aT: A 2-element column vector specifying the acceleration due
% to thrust of the satelite at the current timepoint.
% Parameter mC: A 3-element row vector specyfing the mass of the central body (usually a planet
% or a moon).
% Parameter pC: A 2x3 matrix specifying the position of the central body 
% for timepoints t, t-1 and t-2.
% Parameter h: the difference in time between the current and the next
% timepoint.
% Precondition: All qunatities need to be real-valued and in meters or seconds.
% Return pSr, vSr: 2-element column vectors specifying the position and velocity of 
% the satelite at the next timepoint.
% Postcondition: All qunatities are real-valued and in meters or seconds.
function [pSr, vSr] = adamsBashforthSolve(pS, vS, aT, mC, pC, h)
    % Update position
    pSr = pS(:,3) + (h/12)* (23*vS(:,3) - 16*vS(:,2) + 5*vS(:,1));
    
    % Update velocity
    G = 6.674e-11; % Newtons universal constant of gravity in meters cubed per kg*sec^2
    d_2 = pC(:,1) - pS(:,1); % distance between central body and satelite at t
    aG_2 = G*mC*d_2/norm(d_2)^3; % Acceleration due to gravity at t
    a_2 = aG_2 + aT(:, 1); % Acceleration total at t-1
    d_1 = pC(:,2) - pS(:,2); % distance between central body and satelite at t
    aG_1 = G*mC*d_1/norm(d_1)^3; % Acceleration due to gravity at t
    a_1 = aG_1 + aT(:,2); % Acceleration total at t-1
    
    d = pC(:,3) - pS(:,3); % distance between central body and satelite at t
    
    aG = G*mC*d/norm(d)^3; % Acceleration due to gravity at t
    a = aG + aT(:,3); % Acceleration total at t
    vSr = vS(:,3) + (h/12)* (23*a - 16*a_1 + 5*a_2);
    
end