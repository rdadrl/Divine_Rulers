% Summary: Solves the differential equation describing the motion of a
% satelite depending on its position, gravity and thrust.
% Parameter pS, vS, aT: 2-element column vectors specifying the 
% position, velocity and acceleration due to thrust of the satelite at the current timepoint. 
% Parameter mC, pC: 2-element column vectors specifying the the mass and the position 
% of the central body (usually a planet or a moon).
% Parameter h: A scalar specifying the difference in time between the current and the next
% timepoint.
% Precondition: All qunatities need to be real-valued and in meers or seconds.
% Return pS, vS: 2-element column vectors specifying the position and velocity of 
% the satelite at the next timepoint.
% Postcondition: All qunatities are real-valued and in meters or seconds.
function [pS, vS] = eulerSolve(pS, vS, aT, mC, pC, h)
    % Update position
    pS = pS + h* vS;
    
    % Update velocity
    G = 6.674e-11; % Newtons universal constant of gravity in meters cubed per kg*sec^2
    d = pC - pS; % distance between central body and satelite
    aG = G*mC*d/norm(d)^3; % Acceleration due to gravity
    vS = vS + h* (aG + aT);
end