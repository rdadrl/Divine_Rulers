function [a, ] = orbitalElements(r, v)
u = 1; v = 1; g = 1.352; theta = 1;
dotdotX = @(u, thetha, t)u*sin(theta);
dotdotY = u*cos(theta)-g;
dotdottheta = v;
tSpan = [0 10];
[t, y] = ode23(f,tSpan,y0);

% Determine semimajor axis
muh = G(mTitan + mRocket);
r = position;
v = velocity;
C = v'*v/2 - muh/norm(r); % Energy
a = -muh./2.*C;

% Determine eccentricity
e = norm(A)/muh;
A = v.cross(h) - muh*r./norm(r) % Laplacian vector
h = r.cross(v) % Angular momentum

% Determine time spent in orbit between two points
dt = sqrt(a/muh)*(alph - sin(alp)- beta + sin(beta));
alph = 2*sininv(sqrt((norm(r1)+norm(r2)+norm(d))/4*a));
beta  = 2*sininv(sqrt((norm(r1)+norm(r2)-norm(d))/4*a));

% Period of circular orbit
%TRocket0 = 2*pi*norm(Rocket.position)/norm(Rocket.velocity); % Period of parking orbit

% Geostationary orbit
%Rocket.position = [0; 1].* nthroot((G*Titan.mass*Titan.rotationPeriod^2/(4*pi^2)),3); % Position reltative to Titans center in meters https://socratic.org/questions/how-do-you-calculate-the-altitude-and-velocity-of-a-satellite-in-a-geosynchronou
%Rocket.velocity = [-1; 0].*2*pi*nthroot((G*Titan.mass*Titan.rotationPeriod^2/(4*pi^2)),3)/Titan.rotationPeriod; % Velocity in meters per second https://socratic.org/questions/how-do-you-calculate-the-altitude-and-velocity-of-a-satellite-in-a-geosynchronou

% Plotting monitor
% Plot the distance to Titan
    subplot(2,2,2); title('Distance to Titan');
    plot(ms(1,1:n+1));
    xlabel('t(sec)'); ylabel('distance(m)');
    % Plot the velocity during flight
    subplot(2,2,3); title('Velocity');
    plot(ms(2,1:n+1));
    xlabel('t(sec)'); ylabel('velocity(m/s)');
    % Plot the acceleration during fligt
    subplot(2,2,4); title('Acceleration');
    plot(ms(3,20:n+1));
    xlabel('t(sec)'); ylabel('acceleration (m/s^2)');

    % Update rocket monitor
ms = [[norm(Rocket.position - Titan.position); norm(Rocket.velocity); Thrust(1)/Rocket.mass], zeros(3, n)];

    ms(1,i+1) = norm(ys(1:2,i+1) - Titan.position); % Next distance from titan
    ms(2,i+1) = norm(ys(3:4,i+1)); % Next speed
    ms(3,i+1) = (norm(ys(3:4,i+1))-norm(ys(3:4,i))); % Next acceleration
   